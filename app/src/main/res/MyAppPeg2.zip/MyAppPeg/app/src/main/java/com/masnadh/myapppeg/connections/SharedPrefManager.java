package com.masnadh.myapppeg.connections;

import android.content.Context;

public class SharedPrefManager {

    private static SharedPrefManager mInstance;
    private static Context context;



}
