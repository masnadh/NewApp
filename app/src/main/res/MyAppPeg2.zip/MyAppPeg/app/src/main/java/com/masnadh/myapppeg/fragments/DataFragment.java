package com.masnadh.myapppeg.fragments;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.masnadh.myapppeg.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * A simple {@link Fragment} subclass.
 */
public class DataFragment extends Fragment {

    final String url = "http://152746201341.ip-dynamic.com/ptk/api/pegawai.php";

    TextView tvNama,tvNip;
    String id;
    SharedPreferences sharedpreferences;
    public final static String TAG="Profile";
    public final static String TAG_IDU = "idu";
    RequestQueue requestQueue;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_data, container,false);

        tvNama = (TextView) view.findViewById(R.id.detail_nama);
        tvNip = (TextView)  view.findViewById(R.id.detail_nip);

//        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
//        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                try {
//                    JSONArray array = new JSONArray(response);
//
//                    for (int i =0; i < array.length(); i++){
//                        JSONObject object = array.getJSONObject(i);
//                        String nama = object.getString("nama");
//                        int extraId = Integer.parseInt(getActivity().getIntent().getStringExtra(TAG_IDU));
//
//                    }
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//
//            }
//        })

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        StringRequest stringRequests = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONArray dataArray = new JSONArray(response);

                    for (int i =0; i < dataArray.length(); i++)
                    {

                        JSONObject obj = dataArray.getJSONObject(i);
                      //  int extraId = Integer.parseInt(getActivity().getIntent().getStringExtra(TAG_IDU));
                        //int extraId = Integer.parseInt(getActivity().getIntent().getStringExtra(TAG_IDU));
                        //int extraId = Integer.parseInt(getActivity().getIntent().getStringExtra(TAG));
                        String nama = obj.getString("nama");
                        //int id = obj.getInt("id");
                        String nip = obj.getString("nip");

                        tvNama.setText(nama);
                        tvNip.setText(nip);

//                        if ( extraId == id) {
//
//
//
//                        }
                    }
                    Log.d(TAG, "onResponse:" + response);
                }  catch(
                        JSONException e)

                {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvNama.setText(error.getLocalizedMessage());
            }
        });
        requestQueue.add(stringRequests);
        return view;

           }

}
