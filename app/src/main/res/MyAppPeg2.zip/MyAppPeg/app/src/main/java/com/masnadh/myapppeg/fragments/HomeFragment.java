package com.masnadh.myapppeg.fragments;


import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.masnadh.myapppeg.MainActivity;
import com.masnadh.myapppeg.R;
import com.masnadh.myapppeg.activities.AbsenActivity;
import com.masnadh.myapppeg.activities.DataActivity;
import com.masnadh.myapppeg.activities.PendidikanActivity;
import com.masnadh.myapppeg.activities.PendukungActivity;
import com.masnadh.myapppeg.activities.RiwayatPegActivity;
import com.masnadh.myapppeg.activities.RombelActivity;
import com.masnadh.myapppeg.activities.SKPActivity;
import com.masnadh.myapppeg.activities.UbahActivity;
import com.masnadh.myapppeg.adapters.DashboardAdapter;
import com.masnadh.myapppeg.models.dashboard;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static android.os.Looper.prepare;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private Context mContext;

    private RecyclerView recyclerView;
    private DashboardAdapter adapter;
    private ArrayList<dashboard> dashboards = new ArrayList<>();
    private String[] menuName;
    private TypedArray menuPhoto;

    RelativeLayout rlTop;
    AppBarLayout appBar;
    CollapsingToolbarLayout ctLayout;
    Toolbar toolbar;

    boolean ExpandedActionBar = true;


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_home, container, false);

//        adapter = new DashboardAdapter(this.getContext());
        rlTop = view.findViewById(R.id.rlTop);
        appBar = view.findViewById(R.id.appBar);
        ctLayout = view.findViewById(R.id.cToolbar);
        toolbar = view.findViewById(R.id.toolbar);

        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        ctLayout.setTitle("");

        ctLayout.setCollapsedTitleTextColor(ContextCompat.getColor((AppCompatActivity)getActivity(), R.color.white));
        ctLayout.setExpandedTitleColor(ContextCompat.getColor((AppCompatActivity)getActivity(), R.color.colorPrimary));

            appBar.addOnOffsetChangedListener(new AppBarLayout.BaseOnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (Math.abs(verticalOffset) > 200){
                    ExpandedActionBar = false;
                    ctLayout.setTitle("Sistem Informasi Kepegawaian");
                    rlTop.setVisibility(View.GONE);
                    getActivity().invalidateOptionsMenu();
                } else {
                    ExpandedActionBar = true;
                    ctLayout.setTitle("");
                    rlTop.setVisibility(View.VISIBLE);
                    getActivity().invalidateOptionsMenu();
                }
            }
        });

//        ImageView imgProfile = view.findViewById(R.id.ivProfile);
//        Glide.with(mContext)
//                .load(R.drawable.smk)
//                .apply(RequestOptions.circleCropTransform())
//                .into(imgProfile);

        adapter = new DashboardAdapter(mContext, dashboards);

        RecyclerView rvList = view.findViewById(R.id.rvData);
        rvList.setAdapter(adapter);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(mContext,2);
        rvList.setLayoutManager(layoutManager);



//        recyclerView.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(10), true));
//        recyclerView.setItemAnimator(new DefaultItemAnimator());
        adapter.setOnItemClickListener(new DashboardAdapter.onItemClickListener() {
            @Override
            public void OnItemClick(int position) {
                switch (position){
                    case 0:
                        Intent intent = new Intent(HomeFragment.this.getContext(), DataActivity.class);
                        intent.putExtra("extra_menu_data", dashboards.get(position));
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent1 = new Intent(HomeFragment.this.getContext(), UbahActivity.class);
                        intent1.putExtra("extra_menu_ubah", dashboards.get(position));
                        startActivity(intent1);
                        break;
                    case 2:
                        Toast.makeText(getActivity().getBaseContext(), "Menu Masih Dalam Proses Pengembangan", Toast.LENGTH_SHORT).show();
//                        Intent intent2 = new Intent(HomeFragment.this.getContext(), PendukungActivity.class);
//                        intent2.putExtra("extra_menu_pendukung", dashboards.get(position));
//                        startActivity(intent2);
                        break;
                    case 3:
                        Toast.makeText(getActivity().getBaseContext(), "Menu Masih Dalam Proses Pengembangan", Toast.LENGTH_SHORT).show();
//                        Intent intent3 = new Intent(HomeFragment.this.getContext(), RiwayatPegActivity.class);
//                        intent3.putExtra("extra_menu_peg", dashboards.get(position));
//                        startActivity(intent3);
                        break;
                    case 4:
                        Toast.makeText(getActivity().getBaseContext(), "Menu Masih Dalam Proses Pengembangan", Toast.LENGTH_SHORT).show();
//                        Intent intent4 = new Intent(HomeFragment.this.getContext(), PendidikanActivity.class);
//                        intent4.putExtra("extra_menu_pendidikan", dashboards.get(position));
//                        startActivity(intent4);
                        break;
                    case 5:
                        Toast.makeText(getActivity().getBaseContext(), "Menu Masih Dalam Proses Pengembangan", Toast.LENGTH_SHORT).show();
//                        Intent intent5 = new Intent(HomeFragment.this.getContext(), SKPActivity.class);
//                        intent5.putExtra("extra_menu_skp", dashboards.get(position));
//                        startActivity(intent5);
                        break;
                    case 6:
                        Toast.makeText(getActivity().getBaseContext(), "Menu Masih Dalam Proses Pengembangan", Toast.LENGTH_SHORT).show();
//                        Intent intent6 = new Intent(HomeFragment.this.getContext(), RombelActivity.class);
//                        intent6.putExtra("extra_menu_rombel", dashboards.get(position));
//                        startActivity(intent6);
                        break;
                    case 7:
                        Toast.makeText(getActivity().getBaseContext(), "Menu Masih Dalam Proses Pengembangan", Toast.LENGTH_SHORT).show();
//                        Intent intent7 = new Intent(HomeFragment.this.getContext(), AbsenActivity.class);
//                        intent7.putExtra("extra_menu_absensi", dashboards.get(position));
//                        startActivity(intent7);
                        break;

                }

//                Intent intent = new Intent(HomeFragment.this.getContext(), DataActivity.class);
//                intent.putExtra("extra_menu", dashboards.get(position));
//                startActivity(intent);
            }
        });

        prepare();
        addItem();

        return view;
    }

    private void addItem() {
        dashboards = new ArrayList<>();

        for (int i = 0; i < menuName.length; i++){
            dashboard dashboard = new dashboard();
            dashboard.setTitle(menuName[i]);
            dashboard.setImg(menuPhoto.getResourceId(i, -1));
            dashboards.add(dashboard);
        }

        adapter.setDashboardList(dashboards);
    }

    private void prepare(){
        menuName = getResources().getStringArray(R.array.menu_name);
        menuPhoto = getResources().obtainTypedArray(R.array.menu_photo);
    }

}
