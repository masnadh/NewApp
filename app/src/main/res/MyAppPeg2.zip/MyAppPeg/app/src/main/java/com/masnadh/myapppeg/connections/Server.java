package com.masnadh.myapppeg.connections;

public class Server {

    public static final String URL = "http://152746201341.ip-dynamic.com/ptk/api/";

}
